absl-py==0.12.0
aio-pika==6.8.0
aiofiles==0.6.0
aiohttp==3.6.3
aiormq==3.3.1
alabaster==0.7.12
alembic==1.4.3
anaconda-client==1.7.2
anaconda-navigator==1.9.12
anaconda-project==0.8.3
APScheduler==3.7.0
argh==0.26.2
asn1crypto==1.3.0
astroid @ file:///tmp/build/80754af9/astroid_1592495912941/work
astropy==4.0.1.post1
astunparse==1.6.3
async-generator==1.10
async-timeout==3.0.1
atomicwrites==1.4.0
attrs==19.3.0
autopep8==1.5.6
Babel==2.8.0
backcall==0.2.0
backports.functools-lru-cache==1.6.1
backports.shutil-get-terminal-size==1.0.0
backports.tempfile==1.0
backports.weakref==1.0.post1
beautifulsoup4==4.9.1
bidict==0.21.2
bitarray @ file:///tmp/build/80754af9/bitarray_1594753876414/work
bkcharts==0.2
bleach==3.1.5
blis==0.4.1
bokeh @ file:///tmp/build/80754af9/bokeh_1593187602660/work
boto==2.49.0
boto3==1.17.44
botocore==1.20.44
Bottleneck==1.3.2
brotlipy==0.7.0
cachetools==4.2.1
catalogue==1.0.0
certifi==2020.6.20
cffi==1.14.0
chardet==3.0.4
click==7.1.2
cloudpickle @ file:///tmp/build/80754af9/cloudpickle_1594141588948/work
clyent==1.2.2
colorama==0.4.3
colorclass==2.2.0
coloredlogs==14.3
colorhash==1.0.3
conda==4.8.3
conda-build==3.18.11
conda-package-handling==1.7.0
conda-verify==3.4.2
contextlib2==0.6.0.post1
croniter==1.0.10
cryptography==3.4.7
cycler==0.10.0
cymem==2.0.5
Cython @ file:///tmp/build/80754af9/cython_1594831566883/work
cytoolz==0.10.1
dask @ file:///tmp/build/80754af9/dask-core_1594156306305/work
decorator==4.4.2
defusedxml==0.6.0
diff-match-patch @ file:///tmp/build/80754af9/diff-match-patch_1594828741838/work
distributed @ file:///tmp/build/80754af9/distributed_1594750293818/work
dm-tree==0.1.5
dnspython==1.16.0
docopt==0.6.2
docutils==0.16
en-core-web-md @ https://github.com/explosion/spacy-models/releases/download/en_core_web_md-2.2.5/en_core_web_md-2.2.5.tar.gz
entrypoints==0.3
et-xmlfile==1.0.1
fastcache==1.1.0
fbmessenger==6.0.0
filelock==3.0.12
flake8==3.8.3
Flask==1.1.2
fsspec==0.7.4
future==0.18.2
gast==0.3.3
gensim==4.0.1
gevent @ file:///tmp/build/80754af9/gevent_1593009537125/work
gitdb==4.0.7
GitPython==3.1.14
glob2==0.7
gmpy2==2.0.8
google-auth==1.28.0
google-auth-oauthlib==0.4.4
google-pasta==0.2.0
greenlet==0.4.16
grpcio==1.36.1
h11==0.9.0
h5py==2.10.0
HeapDict==1.0.1
html5lib @ file:///tmp/build/80754af9/html5lib_1593446221756/work
httpcore==0.11.1
httplib2==0.19.1
httptools==0.1.1
httpx==0.15.4
humanfriendly==9.1
idna @ file:///tmp/build/80754af9/idna_1593446292537/work
imageio @ file:///tmp/build/80754af9/imageio_1594161405741/work
imagesize==1.2.0
importlib-metadata @ file:///tmp/build/80754af9/importlib-metadata_1593446406207/work
intervaltree @ file:///tmp/build/80754af9/intervaltree_1594361675072/work
ipykernel @ file:///tmp/build/80754af9/ipykernel_1594753368510/work/dist/ipykernel-5.3.2-py3-none-any.whl
ipython @ file:///tmp/build/80754af9/ipython_1593447377063/work
ipython-genutils==0.2.0
ipywidgets==7.5.1
isodate==0.6.0
isort==4.3.21
itsdangerous==1.1.0
jdcal==1.4.1
jedi @ file:///tmp/build/80754af9/jedi_1592841866100/work
jeepney==0.4.3
Jinja2==2.11.2
jmespath==0.10.0
joblib==0.15.1
json5==0.9.5
jsonpickle==2.0.0
jsonschema==3.2.0
jupyter==1.0.0
jupyter-client @ file:///tmp/build/80754af9/jupyter_client_1594826976318/work
jupyter-console==6.1.0
jupyter-core==4.6.3
jupyterlab==2.1.5
jupyterlab-server @ file:///tmp/build/80754af9/jupyterlab_server_1594164409481/work
kafka-python==1.4.7
Keras-Preprocessing==1.1.2
keyring @ file:///tmp/build/80754af9/keyring_1593109721646/work
kiwisolver==1.2.0
lazy-object-proxy==1.4.3
libarchive-c==2.9
llvmlite==0.33.0+1.g022ab0f
locket==0.2.0
lxml @ file:///tmp/build/80754af9/lxml_1594826779415/work
Mako==1.1.4
Markdown==3.3.4
MarkupSafe==1.1.1
matplotlib @ file:///tmp/build/80754af9/matplotlib-base_1592846008246/work
mattermostwrapper==2.2
mccabe==0.6.1
mistune==0.8.4
mkl-fft==1.1.0
mkl-random==1.1.1
mkl-service==2.3.0
mock==4.0.2
more-itertools==8.4.0
mpmath==1.1.0
msgpack==1.0.0
multidict==4.7.6
multipledispatch==0.6.0
murmurhash==1.0.5
navigator-updater==0.2.1
nbconvert==5.6.1
nbformat==5.0.7
networkx @ file:///tmp/build/80754af9/networkx_1594377231366/work
nltk @ file:///tmp/build/80754af9/nltk_1592496090529/work
nose==1.3.7
notebook==6.0.3
numba==0.50.1
numexpr==2.7.1
numpy==1.18.5
numpydoc @ file:///tmp/build/80754af9/numpydoc_1594166760263/work
oauth2client==4.1.3
oauthlib==3.1.0
olefile==0.46
openpyxl @ file:///tmp/build/80754af9/openpyxl_1594167385094/work
opt-einsum==3.3.0
packaging==20.4
pamqp==2.3.0
pandas @ file:///tmp/build/80754af9/pandas_1592841659173/work
pandocfilters==1.4.2
parso==0.7.0
partd==1.1.0
path==13.1.0
pathlib2==2.3.5
pathtools==0.1.2
patsy==0.5.1
pep8==1.7.1
pexpect==4.8.0
pickleshare==0.7.5
pika==1.2.0
Pillow @ file:///tmp/build/80754af9/pillow_1594307295532/work
pkginfo==1.5.0.1
plac==1.1.3
pluggy==0.13.1
ply==3.11
preshed==3.0.5
prometheus-client==0.8.0
prompt-toolkit==2.0.10
protobuf==3.15.7
psutil==5.7.0
psycopg2-binary==2.8.6
ptyprocess==0.6.0
py @ file:///tmp/build/80754af9/py_1593446248552/work
pyasn1==0.4.8
pyasn1-modules==0.2.8
pycodestyle==2.7.0
pycosat==0.6.3
pycparser @ file:///tmp/build/80754af9/pycparser_1594388511720/work
pycurl==7.43.0.5
pydocstyle @ file:///tmp/build/80754af9/pydocstyle_1592848020240/work
pydot==1.4.2
pyflakes==2.2.0
Pygments==2.6.1
PyJWT==2.0.0
pykwalify==1.8.0
pylint @ file:///tmp/build/80754af9/pylint_1592496053748/work
pymongo==3.10.1
pyodbc===4.0.0-unsupported
pyOpenSSL @ file:///tmp/build/80754af9/pyopenssl_1594392929924/work
pyparsing==2.4.7
pyrsistent==0.16.0
PySocks==1.7.1
pyTelegramBotAPI==3.7.7
pytest==5.4.3
python-crfsuite==0.9.7
python-dateutil==2.8.1
python-editor==1.0.4
python-engineio==3.13.2
python-jsonrpc-server @ file:///tmp/build/80754af9/python-jsonrpc-server_1594397536060/work
python-language-server @ file:///tmp/build/80754af9/python-language-server_1594161909948/work
python-socketio==5.1.0
pytz==2020.1
PyWavelets==1.1.1
pyxdg==0.26
PyYAML==5.3.1
pyzmq==19.0.1
QDarkStyle==2.8.1
QtAwesome==0.7.2
qtconsole @ file:///tmp/build/80754af9/qtconsole_1592848611704/work
QtPy==1.9.0
questionary==1.5.2
rasa==2.4.3
rasa-sdk==2.4.1
rasa-x==0.38.1
redis==3.5.3
regex @ file:///tmp/build/80754af9/regex_1593435547652/work
requests @ file:///tmp/build/80754af9/requests_1592841827918/work
requests-oauthlib==1.3.0
requests-toolbelt==0.9.1
rfc3986==1.4.0
rocketchat-API==1.15.0
rope==0.17.0
rsa==4.7.2
Rtree==0.9.4
ruamel-yaml==0.15.87
ruamel.yaml.clib==0.2.2
s3transfer==0.3.6
sanic==20.12.3
Sanic-Cors==0.10.0.post3
sanic-jwt==1.6.0
Sanic-Plugins-Framework==0.9.5
scikit-image==0.16.2
scikit-learn @ file:///tmp/build/80754af9/scikit-learn_1592502866053/work
scipy @ file:///tmp/build/80754af9/scipy_1592930511789/work
seaborn==0.10.1
SecretStorage==3.1.2
Send2Trash==1.5.0
sentry-sdk==0.19.5
simplegeneric==0.8.1
singledispatch==3.4.0.3
sip==4.19.13
six==1.15.0
sklearn==0.0
sklearn-crfsuite==0.3.6
sklearn-pandas==2.0.4
slackclient==2.9.3
smart-open==5.0.0
smmap==4.0.0
sniffio==1.2.0
snowballstemmer==2.0.0
sortedcollections==1.2.1
sortedcontainers==2.2.2
soupsieve==2.0.1
spacy==2.2.4
Sphinx @ file:///tmp/build/80754af9/sphinx_1594223420021/work
sphinxcontrib-applehelp==1.0.2
sphinxcontrib-devhelp==1.0.2
sphinxcontrib-htmlhelp==1.0.3
sphinxcontrib-jsmath==1.0.1
sphinxcontrib-qthelp==1.0.3
sphinxcontrib-serializinghtml==1.1.4
sphinxcontrib-websupport @ file:///tmp/build/80754af9/sphinxcontrib-websupport_1593446360927/work
spyder @ file:///tmp/build/80754af9/spyder_1594832131358/work
spyder-kernels @ file:///tmp/build/80754af9/spyder-kernels_1594751551963/work
SQLAlchemy==1.3.24
srsly==1.0.5
statsmodels==0.11.1
sympy @ file:///tmp/build/80754af9/sympy_1594236545715/work
tables==3.6.1
tabulate==0.8.9
tblib==1.6.0
tensorboard==2.4.1
tensorboard-plugin-wit==1.8.0
tensorflow==2.3.2
tensorflow-addons==0.12.0
tensorflow-estimator==2.3.0
tensorflow-hub==0.10.0
tensorflow-probability==0.11.1
tensorflow-text==2.3.0
termcolor==1.1.0
terminado==0.8.3
terminaltables==3.1.0
testpath==0.4.4
textblob==0.15.3
thinc==7.4.0
threadpoolctl @ file:///tmp/tmp9twdgx9k/threadpoolctl-2.1.0-py3-none-any.whl
toml @ file:///tmp/build/80754af9/toml_1592853716807/work
toolz==0.10.0
tornado==6.0.4
tqdm @ file:///tmp/build/80754af9/tqdm_1593446365756/work
traitlets==4.3.3
twilio==6.50.1
typeguard==2.12.0
typing-extensions @ file:///tmp/build/80754af9/typing_extensions_1592847887441/work
tzlocal==2.1
ujson==1.35
unicodecsv==0.14.1
urllib3==1.25.9
uvloop==0.14.0
wasabi==0.8.2
watchdog @ file:///tmp/build/80754af9/watchdog_1593447344699/work
wcwidth @ file:///tmp/build/80754af9/wcwidth_1593447189090/work
webencodings==0.5.1
webexteamssdk==1.6
websockets==8.1
Werkzeug==1.0.1
widgetsnbextension==3.5.1
wrapt==1.11.2
wurlitzer @ file:///tmp/build/80754af9/wurlitzer_1594753850195/work
xlrd==1.2.0
XlsxWriter==1.2.9
xlwt==1.3.0
xmltodict==0.12.0
yapf @ file:///tmp/build/80754af9/yapf_1593528177422/work
yarl==1.6.3
zict==2.0.0
zipp==3.1.0
zope.event==4.4
zope.interface==4.7.1
